package com.steszyngagne.draw.Tools;

public enum ToolName { NONE, LINE, RECTANGLE, SQUARE, CIRCLE, OVAL }