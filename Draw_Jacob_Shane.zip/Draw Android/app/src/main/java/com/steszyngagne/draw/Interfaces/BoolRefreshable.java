package com.steszyngagne.draw.Interfaces;

public interface BoolRefreshable {
    public void afterRefresh(boolean res, int code);
}
